<?php
$valor1=readline("Informe o primeiro valor? ");
$Toperacao=readline("Informe o símbolo da operação? ");
$valor2=readline("Informe o segundo valor? ");

function calculadora($valor1,$valor2,$Toperacao){
  switch($Toperacao){
    case "+" :
      $adValor=$valor1+$valor2;
      echo $adValor;
      break;
    case "-":
      $subtValor=$valor1-$valor2;
      echo $subtValor;
      break;
    case "*":
      $multValor=$valor1*$valor2;
      echo $multValor;
      break;
    case "/":
      $divValor=$valor1/$valor2;
      echo $divValor;
      break;
    default:
      echo"Nenhuma das operações.";
      break;
   }
}

$resultado=calculadora($valor1,$valor2,$Toperacao);
echo $resultado;
?>