<?php
$nums=0;
while(true){
  $num= readline("Informe o valor: ");
  if($num==0){
    break;
  }
  $nums = $nums + $num;
};
echo $nums;

?>