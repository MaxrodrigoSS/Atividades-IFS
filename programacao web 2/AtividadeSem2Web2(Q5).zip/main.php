<?php
$valorT=0;

while(true){
    $valor= readline("Informe o valor: ");
   if($valor==0){
     break;
   };
   $valorT= $valorT+$valor;
};

if($valorT >= 1000){
  $valorPorct=(15/100);
  $valorF= $valorT-($valorT*$valorPorct);
  echo $valorF;
   }else{
     echo $valorT;
};

?>