<?php
$numero=readline("Informe um valor: ");
$digitos=0;

if($numero==0){
  echo $digitos="1"." digito";
}else{
  echo strlen($numero)." digitos";
}
?>